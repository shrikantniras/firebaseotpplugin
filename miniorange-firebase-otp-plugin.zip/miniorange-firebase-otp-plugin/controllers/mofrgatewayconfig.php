<?php

use MoOTP\Helper\MoConstants;
use MoOTP\Helper\MoUtility;
use MoOTP\Objects\PluginPageDetails;
use MoOTP\Objects\Tabs;

$mo_firebase_registration_form_enable = "checked";
$mo_firebase_registration_FormCSS = "#mo_otp{color:red;}";

include MOFLR_DIR . 'views/mofrgatewayconfig.php';