<?php

namespace MoOTP\Helper;

if(! defined( 'ABSPATH' )) exit;


class MoConstants
{   
	const HOSTNAME				= MOFLR_HOST;
	
    const PLUGIN_TYPE            = MOFLR_LICENSE_TYPE;
   	const FROM_EMAIL			= "no-reply@xecurify.com";
	const SUPPORT_EMAIL 		= "info@xecurify.com";
	const FEEDBACK_EMAIL 		= "otpsupport@xecurify.com";
	const AREA_OF_INTEREST      = "WP OTP Firebase Plugin";
    const MOFLRFREE_PLUGIN      = MOFLR_LICENSE_TYPE;
}