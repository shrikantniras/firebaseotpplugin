<?php

namespace MoOTP\Helper;

if(! defined( 'ABSPATH' )) exit;

use MoOTP\MoOTPInitializer;
use MoOTP\Objects\PluginPageDetails;
use MoOTP\Objects\TabDetails;
use MoOTP\Traits\Instance;


final class FreePlan
{
    use Instance;
    
    private function __construct()
    {
        
    }

}